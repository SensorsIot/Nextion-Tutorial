var _nex_touch_8h =
[
    [ "NEX_EVENT_POP", "group___touch_event.html#ga5db3d99f88ac878875ca47713b7a54b6", null ],
    [ "NEX_EVENT_PUSH", "group___touch_event.html#ga748c37a9bbe04ddc680fe1686154fefb", null ],
    [ "NexTouchEventCb", "group___touch_event.html#ga162dea47b078e8878d10d6981a9dd0c6", null ]
];